# Reflection

> Note: The uploaded three-page handout mentions reflection questions but does not show their exact wording. These concise responses cover the lab's stated learning outcomes. Match them to the exact questions in your lab manual if a separate question sheet was provided.

### 1. What is static code analysis, and why is it useful?
Static code analysis checks source code without executing the program. It helps identify possible bugs, security weaknesses, and style problems early, making the program safer and easier to maintain.

### 2. What are the roles of Pylint, Bandit, and Flake8?
Pylint checks general code quality, naming, unused variables, and programming practices. Bandit looks for common security weaknesses. Flake8 checks Python formatting and PEP 8 style rules such as whitespace and line length.

### 3. What issues were identified and fixed in this program?
The program contained unsafe `eval()`, a shell command built with `os.system()`, a hard-coded secret, weak MD5 hashing, a mutable default list, a bare exception handler, and file handling without a context manager. These were replaced with safer and clearer approaches.

### 4. How did static analysis improve the program?
The tools helped identify problems that were easy to overlook during normal execution. Fixing them improved security, reliability, readability, and maintainability while preserving the gym membership program's main functions.
