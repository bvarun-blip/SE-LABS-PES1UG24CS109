# Issue Identification and Fixes

| Issue | Type / Tool | Original line(s) | Description | Fix approach |
|---|---|---:|---|---|
| Unsafe `eval()` | Security - Bandit | 37-40 | Evaluating a string can execute arbitrary Python code. | Replaced the expression argument with a numeric discount rate and validated its range. |
| Shell command construction with `os.system()` | Security - Bandit | 51-55 | Passing a filename into a shell command can allow command injection. | Removed the shell call and used Python's `print()` for the status message. |
| Hard-coded portal secret | Security - Bandit / code security | 64-74 | A secret embedded in source code can be exposed to anyone with repository access. | Removed the hard-coded secret and stopped printing it. |
| Weak MD5 hash | Security - Bandit | 43-44 | MD5 is not suitable for security-sensitive hashing. | Replaced MD5 with SHA-256. |
| Non-cryptographic random PIN | Security - code security | 47-48 | The `random` module is not intended for security-sensitive values. | Replaced it with `secrets.randbelow()` to generate the four-digit PIN. |
| Mutable default argument | Bug - Pylint | 14-19 | A list used as a default argument is shared between function calls. | Changed the default to `None` and created a new list inside the function. |
| Bare `except` block | Reliability - Pylint | 22-26 | It catches every exception and hides unexpected errors. | Replaced the try/except block with `dict.pop(member_id, None)`. |
| Unused variable and `== None` | Code quality - Pylint | 29-32 | `locker_deposit` was unused and comparing to `None` is not the preferred check. | Removed the unused variable and used a membership lookup with a `None` check. |
| File opened without a context manager | Reliability / style - Pylint | 51-54 | The file may not be closed if an error occurs while writing. | Used `with open(..., encoding="utf-8")` so the file is closed automatically. |
| Style and naming inconsistencies | Style - Flake8 / Pylint | Throughout | Function names and spacing did not consistently follow Python conventions. | Used snake_case names, consistent indentation, blank lines, and readable formatting. |

## Verification

Run Pylint, Bandit, and Flake8 again after replacing the original file. Record the actual results from your terminal in the six report files; do not manually assume a score or mark a check as passed unless the tool output confirms it.
